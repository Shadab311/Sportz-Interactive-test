﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapTwoNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int a, b;
                Console.WriteLine("Enter 1st Number : ");
                a = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter 2nd Number : ");
                b = int.Parse(Console.ReadLine());

                Console.WriteLine("Before swap 1st Number= {0} 2nd Number= {1}", a, b);
                a = a * b; //a=50 (5*10)      
                b = a / b; //b=5 (50/10)      
                a = a / b; //a=10 (50/5)    
                Console.WriteLine("After swap 1st Number= {0} 2nd Number= {1}", a, b);
            }
            catch (Exception ex)
            {
                //If user enters anything other than a numbers
                if (ex.Message.Contains("format"))
                    Console.WriteLine("Error: Entered value is not valid number");
                else
                {
                    Console.WriteLine("Error:{0}", ex.Message);
                }
            }
            Console.ReadKey();
        }
    }
}
