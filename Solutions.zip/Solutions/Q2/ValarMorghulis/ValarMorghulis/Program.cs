﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValarMorghulis
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 100; i++) //Run loop from 1 to 100
            {
                if (i % 3 == 0 && i % 5 == 0) //Check if number is divisible by 3 & 5
                {
                    Console.WriteLine("valar morghulis"); 
                }
                else if (i % 3 == 0) //Check if number is divisible by 3
                {
                    Console.WriteLine("valar");
                }
                else if (i % 5 == 0) //Check if number is divisible by 3
                {
                    Console.WriteLine("morghulis");
                }
                else //Else print the number
                {
                    Console.WriteLine(i.ToString());
                }
            }

            Console.ReadKey();
        }
    }
}
