﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IterateThroughEnum
{
    /// <summary>
    /// Enum of Colors
    /// </summary>
    public enum Colors
    {
        red,
        blue,
        green,
        yellow
    }
    class Program
    {
        static void Main(string[] args)
        {
            foreach (var clr in Enum.GetValues(typeof(Colors)))//Get each value in enum and write to console
            {
                Console.WriteLine(clr.ToString());
            }

            Console.ReadKey();
        }
    }
}
