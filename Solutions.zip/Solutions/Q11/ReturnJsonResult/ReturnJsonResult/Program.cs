﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReturnJsonResult
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create object for serialization
            var obj = new Team
            {
                NameFull = "Sunrisers Hyderabad",
                NameShort = "SRH",
                Players = new Dictionary<string, Player>
                {
                    {"5380", new Player() {Position = "1", NameFull = "David Warner", IsCaptain = true } },
                    {"3722", new Player() {Position = "2", NameFull = "Shikhar Dhawan", IsCaptain = false } }
                }
            };

            var srlz = JsonConvert.SerializeObject(obj); //Serilaize the object to JSON
            Console.WriteLine("Converted Json is:");
            Console.WriteLine(srlz); //The generated JSON

            Console.ReadKey();
        }
    }

    public class Team
    {
        [JsonProperty("Name_Full")]
        public string NameFull { get; set; }

        [JsonProperty("Name_Short")]
        public string NameShort { get; set; }

        [JsonProperty("Players")]
        public Dictionary<string, Player> Players { get; set; }
    }

    public class Player
    {
        [JsonProperty("Position")]
        public string Position { get; set; }

        [JsonProperty("Name_Full")]
        public string NameFull { get; set; }

        [JsonProperty("IsCaptain")]
        public bool IsCaptain { get; set; }
    }
}
