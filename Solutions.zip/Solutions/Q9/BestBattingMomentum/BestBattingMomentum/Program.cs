﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BestBattingMomentum
{
    class Program
    {
        static void Main(string[] args)
        {
            string jsonString = "[\n{\"Batsman\": \"Virat Kholi\", \"RunsScored\": 50, \"StrikeRate\": 78.30},\n{\"Batsman\": \"M.S.Dhoni\", \"RunsScored\": 61, \"StrikeRate\": 58.90},\n{\"Batsman\": \"Rohit Sharma\", \"RunsScored\": 13, \"StrikeRate\": 124.0}\n]";
            var players = JsonConvert.DeserializeObject<List<Player>>(jsonString); //Deserialize json to List<Player>

            var best = players.First(p => (p.RunsScored * p.StrikeRate) == players.Max(pl => pl.RunsScored * pl.StrikeRate)); //Select player with best momentum

            Console.WriteLine("Player with best batting Momentum is {0}", best.Batsman); //Print Name of player with best momentum
            Console.ReadKey();
        }
    }

    public class Player
    {
        public string Batsman { get; set; }
        public int RunsScored { get; set; }
        public double StrikeRate { get; set; }
    }
}
