﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CircumferenceOfCircle
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle cir = new Circle();

            //Use reflection to modify private variable of sealed class, uncomment below code to pass value for radius
            //var field = cir.GetType().GetField("radius", BindingFlags.Instance | BindingFlags.NonPublic);
            //field.SetValue(cir, 5);

            //Always returns 0 as radius in circle class has default value 0
            double circumference = cir.Calculate(r => 2 * Math.PI * r); //Lambda expression for anonymous delegate

            Console.WriteLine(circumference.ToString());
            Console.ReadKey();
        }
    }

    public sealed class Circle
    {
        private double radius;
        public double Calculate(Func<double, double> op)
        {
            return op(radius);
        }
    }
}

