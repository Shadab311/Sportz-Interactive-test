﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindNthFiboNumber
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter nth value of Fibonacci : ");            
            int num = int.Parse(Console.ReadLine()); //Read Nth fibo value to be found

            int result = PrintnthFibo(num);

            Console.WriteLine("The {0}th term of Fibonacci Series is {1}", num, result);

            Console.ReadKey();
        }

        /// <summary>
        /// Value at Nth position of fibonacci series
        /// </summary>
        /// <param name="nth">Nth number</param>
        /// <returns></returns>
        public static int PrintnthFibo(int nth)
        {
            if (nth == 1)
            {
                return 0;
            }
            else if (nth <= 3)
            {
                return 1;
            }
            else
            {
                return PrintnthFibo(nth - 1) + PrintnthFibo(nth - 2); //Make a call to PrintnthFibo() recursively
            }
        }
    }
}
