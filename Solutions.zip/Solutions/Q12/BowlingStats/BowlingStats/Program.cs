﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingStats
{
    class Program
    {
        static void Main(string[] args)
        {
            string lineUpsStr = "[\n{\"PlayerId\" : 21,\"PlayerName\": \"Y. Chahal\"},\n{\"PlayerId\" : 22,\"PlayerName\": \"Bhuvneshwar Kumar\"},\n{\"PlayerId\" : 23,\"PlayerName\": \"Jasprit Bumrah\"},\n{\"PlayerId\" : 24,\"PlayerName\": \"Hardik Pandya\"},\n{\"PlayerId\" : 25,\"PlayerName\": \"Ravindra Jadeja\"},\n{\"PlayerId\" : 26,\"PlayerName\": \"Mohammed Shami\"}\n]";
            string bowlingStatStr = "[\n{\"PlayerId\" : 21, \"Wickets\": 2},\n{\"PlayerId\" : 22, \"Wickets\": 1},\n{\"PlayerId\" : 23, \"Wickets\": 3},\n{\"PlayerId\" : 26, \"Wickets\": 1}\n]";

            var lineUps = JsonConvert.DeserializeObject<List<LineUp>>(lineUpsStr);
            var bowlingStat = JsonConvert.DeserializeObject<List<BowlingStat>>(bowlingStatStr);

            //Perform left join to get all values from LineUps and respective matching values from Wickets if null than show as 0
            var result = from lu in lineUps
                         join bs in bowlingStat on lu.PlayerId equals bs.PlayerId
                         into temp
                         from blwst in temp.DefaultIfEmpty()
                         select new
                         {
                             PlayerName = lu.PlayerName,
                             Wickets = blwst == null ? 0 : blwst.Wickets
                         };

            foreach (var res in result)
            {
                Console.WriteLine("{0} has take {1} Wickets", res.PlayerName, res.Wickets);
            }

            Console.ReadKey();
        }
    }

    public class LineUp
    {
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
    }

    public class BowlingStat
    {
        public int PlayerId { get; set; }
        public int? Wickets { get; set; }
    }
}
