﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatePowerOfNumber
{
    class Program
    {
        public static void Main(string[] args)
        {
            int n, p;
            long res;

            Console.WriteLine("Enter number for which to calculate power : ");
            n = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter power : ");
            p = int.Parse(Console.ReadLine());

            res = Power(n, p);

            Console.WriteLine("{0}^{1} = {2}",n,p,res);
            Console.ReadKey();
        }

        /// <summary>
        /// Returns power of a number
        /// </summary>
        /// <param name="n">Number to find power of</param>
        /// <param name="p">Power</param>
        /// <returns></returns>
        static long Power(int n, int p)
        {
            if (p != 0)
            {
                return (n * Power(n, p - 1)); //Calulate power of number using recursion
            }
            return 1;
        }
    }
}
