﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChangeIsRetiredFlag
{
    class Program
    {
        static void Main(string[] args)
        {
            string jsonString = "[{\"PlayerName\":\"ViratKholi\",\"IsRetired\":1},{\"PlayerName\":\"M.S.Dhoni\",\"IsRetired\":1},{\"PlayerName\":\"HardikPandya\",\"IsRetired\":1},{\"PlayerName\":\"RohitSharma\",\"IsRetired\":1},{\"PlayerName\":\"SachinTendulkar\",\"IsRetired\":0},{\"PlayerName\":\"RahulDravid\",\"IsRetired\":0},{\"PlayerName\":\"SouravGanguly\",\"IsRetired\":0},{\"PlayerName\":\"VVSLaxman\",\"IsRetired\":0}]";
            var players = JsonConvert.DeserializeObject<List<Player>>(jsonString);

            var newPlayers = players.Select(p => { if (p.IsRetired == 1) p.IsRetired = 0; else p.IsRetired = 1; return p; }).ToList(); //Change IsRetired value to 0 if it is 1 and vice versa
            string correctedJson = JsonConvert.SerializeObject(players); //Serilize to JSON format

            Console.WriteLine("Corrected json is:");
            Console.WriteLine(correctedJson); //Print corrected json

            Console.ReadKey();
        }
    }

    public class Player
    {
        public string PlayerName { get; set; }
        public int IsRetired { get; set; }
    }
}
