﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateArea
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create instance of AreaOfShape Class
            AreaOfShape s = new AreaOfShape();

            //Overload methods work according to passed values
            s.Area(10);
            s.Area(10, 20);
            Console.ReadKey();
        }
    }

    class AreaOfShape
    {
        /// <summary>
        /// Calulates and resturns area of Square
        /// </summary>
        /// <param name="side">The side.</param>
        public void Area(int side)
        {
            int squarearea = side * side;
            Console.WriteLine("The Area of Square is :" + squarearea);
        }

        /// <summary>
        /// Calulates and resturns area of Rectangle
        /// </summary>
        /// <param name="length">The length.</param>
        /// <param name="breadth">The breadth.</param>
        public void Area(int length, int breadth)
        {
            int rectarea = length * breadth;
            Console.WriteLine("The Area of Rectangle is :" + rectarea);
        }

    }
}
