﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfEvenIntegers
{
    class Program
    {
        /// <summary>
        /// Entry point of program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter number of array elements : ");

                //Read number of elements in array
                int nums = int.Parse(Console.ReadLine());
                int[] arr = new int[nums];

                //Get get values from user
                Console.WriteLine("Enter array elements : ");
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.Write("Element[" + (i + 1) + "]: ");
                    arr[i] = int.Parse(Console.ReadLine());
                }

                int result = SumOfEvenIntegers(arr);

                Console.WriteLine("Sum of even integers = {0}", result);
            }
            catch (Exception ex)
            {
                //If user enters anything other than a numbers
                if (ex.Message.Contains("format"))
                    Console.WriteLine("Error: Entered value is not valid number");
                else
                {
                    Console.WriteLine("Error:{0}", ex.Message);
                }
            }
            Console.ReadKey();
        }

        /// <summary>
        /// Sums the of even integers.
        /// </summary>
        /// <param name="arr">Array integers</param>
        /// <returns>Sum of intergers</returns>
        public static int SumOfEvenIntegers(int[] arr)
        {
            int sum = 0;
            foreach (var num in arr)
            {
                if (num % 2 == 0)
                {
                    sum += num;
                }
            }

            return sum;
        }
    }
}
